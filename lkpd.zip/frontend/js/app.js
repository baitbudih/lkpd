const user=JSON.parse(localStorage.getItem("user")||"null");
if(!user||!localStorage.getItem("sessionToken")) location.href="login.html";
document.getElementById("userName").textContent=user.nama;
document.getElementById("greeting").textContent=`Halo, ${user.nama} 👋`;

function logout(){apiPost({action:"logout"}).finally(()=>{localStorage.clear();location.href="login.html"})}
async function loadStudent(){
  const r=await apiGet("getActiveLKPD");
  const el=document.getElementById("lkpdList"); el.innerHTML="";
  (r.data||[]).forEach(x=>el.innerHTML+=`<div class="card lkpd-card"><h3>${esc(x.judul)}</h3><p>${esc(x.materi)}</p><p class="muted">${esc(x.deskripsi||"")}</p><a class="btn" href="quiz.html?lkpd=${encodeURIComponent(x.id)}">Mulai Quiz</a></div>`);
}
async function loadTeacher(){
  const r=await apiGet("getClassRecap");
  document.getElementById("classRecap").innerHTML=(r.data||[]).map(x=>`<div class="card"><b>${esc(x.kelas)}</b><br>Siswa: ${x.siswa} · Peserta: ${x.peserta} · Rata-rata: ${x.rata2}</div>`).join("");
}
async function loadAdmin(){
  const r=await apiGet("getDashboard");
  document.getElementById("statStudents").textContent=r.data.students;
  document.getElementById("statLKPD").textContent=r.data.lkpd;
  document.getElementById("statAttempts").textContent=r.data.attempts;
  document.getElementById("statAvg").textContent=r.data.average;
  document.querySelector("#recentTable tbody").innerHTML=(r.data.recent||[]).map(x=>`<tr><td>${esc(x.nama)}</td><td>${esc(x.kelas)}</td><td>${esc(x.lkpd)}</td><td>${x.skor}</td></tr>`).join("");
}
async function exportExcel(){
  const r=await apiGet("exportExcel");
  if(!r.success){alert(r.message);return}
  const bytes=Uint8Array.from(atob(r.base64),c=>c.charCodeAt(0));
  const blob=new Blob([bytes],{type:"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"});
  const a=document.createElement("a"); a.href=URL.createObjectURL(blob); a.download=r.filename||"rekap.xlsx"; a.click(); URL.revokeObjectURL(a.href);
}
function esc(v){return String(v??"").replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[m]))}

if(user.role==="SISWA"){document.getElementById("studentPanel").classList.remove("hidden");loadStudent();}
if(user.role==="GURU"){document.getElementById("teacherPanel").classList.remove("hidden");loadTeacher();}
if(user.role==="ADMIN"){document.getElementById("adminPanel").classList.remove("hidden");loadAdmin();}
