document.getElementById("loginForm").addEventListener("submit", async e=>{
  e.preventDefault();
  const msg=document.getElementById("msg"); msg.textContent="Memeriksa...";
  const r=await apiPost({action:"login",username:document.getElementById("username").value.trim(),password:document.getElementById("password").value});
  if(r.success){
    localStorage.setItem("sessionToken",r.token);
    localStorage.setItem("user",JSON.stringify(r.user));
    location.href="dashboard.html";
  }else msg.textContent=r.message||"Login gagal.";
});
