function requireStaff(){const u=JSON.parse(localStorage.getItem("user")||"null");if(!u||!["ADMIN","GURU"].includes(u.role))location.href="login.html"} requireStaff();
async function load(){const r=await apiGet("listLKPD");document.getElementById("rows").innerHTML=(r.data||[]).map(x=>`<tr><td>${esc(x.judul)}</td><td>${esc(x.materi)}</td><td>${x.status}</td><td><button class="btn small" onclick='edit(${JSON.stringify(x)})'>Edit</button> <button class="btn small danger" onclick="del('${x.id}')">Hapus</button></td></tr>`).join("")}
document.getElementById("lkpdForm").onsubmit=async e=>{e.preventDefault();const r=await apiPost({action:"saveLKPD",id:id.value,judul:judul.value,materi:materi.value,deskripsi:deskripsi.value,status:status.value});alert(r.message);if(r.success){resetForm();load()}}
function edit(x){id.value=x.id;judul.value=x.judul;materi.value=x.materi;deskripsi.value=x.deskripsi||"";status.value=x.status;scrollTo({top:0,behavior:"smooth"})}
async function del(x){if(confirm("Hapus LKPD?")){const r=await apiPost({action:"deleteLKPD",id:x});alert(r.message);load()}}
function resetForm(){document.getElementById("lkpdForm").reset();id.value=""}
function esc(v){return String(v??"").replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[m]))} load();
