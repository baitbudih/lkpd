const user=JSON.parse(localStorage.getItem("user")||"null");
if(!user) location.href="login.html";
const lkpdId=new URLSearchParams(location.search).get("lkpd");
let questions=[];
async function loadQuiz(){
  const r=await apiGet("getQuiz",{lkpdId});
  if(!r.success){alert(r.message);return}
  questions=r.data; document.getElementById("title").textContent=r.title||"Quiz";
  document.getElementById("quiz").innerHTML=questions.map((q,i)=>`
    <div class="question"><b>${i+1}. ${esc(q.pertanyaan)}</b>
      ${["A","B","C","D"].map(k=>`<label class="option"><input type="radio" name="q_${q.id}" value="${k}"> ${k}. ${esc(q[k])}</label>`).join("")}
    </div>`).join("");
}
document.getElementById("submit").onclick=async()=>{
  const answers={};
  questions.forEach(q=>{const x=document.querySelector(`input[name="q_${q.id}"]:checked`);answers[q.id]=x?x.value:"";});
  const r=await apiPost({action:"submitQuiz",lkpdId,answers});
  if(r.success){document.getElementById("result").innerHTML=`<div class="result"><h2>Skor: ${r.data.skor}</h2><p>Benar: ${r.data.benar} · Salah: ${r.data.salah} · Kosong: ${r.data.kosong}</p></div>`;document.getElementById("submit").disabled=true}
  else alert(r.message);
}
function esc(v){return String(v??"").replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[m]))}
loadQuiz();
